cd docs
pydoc -w pymedia pymedia.audio pymedia.audio.sound pymedia.removable.cd pymedia.removable pymedia.audio.acodec pymedia.video pymedia.video.muxer pymedia.video.vcodec
mv pymedia.html index.html
cd ..
